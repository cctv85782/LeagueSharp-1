﻿namespace RethoughtLib.Classes.General_Intefaces
{
    public interface INamable
    {
        #region Public Properties

        /// <summary>
        ///     Gets or sets the name.
        /// </summary>
        /// <value>
        ///     The name.
        /// </value>
        string Name { get; set; }

        #endregion
    }
}