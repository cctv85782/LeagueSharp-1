﻿namespace RethoughtLib.Classes.General_Intefaces
{
    public interface ILoadable
    {
        #region Public Methods and Operators

        /// <summary>
        ///     Loads this instance.
        /// </summary>
        void Load();

        #endregion
    }
}