﻿namespace RethoughtLib.Utility
{
    internal class Logger
    {
        public static void Catch()
        {
            
        }
    }
}
