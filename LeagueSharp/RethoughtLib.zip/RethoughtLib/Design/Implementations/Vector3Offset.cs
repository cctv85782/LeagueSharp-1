﻿namespace RethoughtLib.Design.Implementations
{
    #region Using Directives

    using SharpDX;

    #endregion

    public class Vector3Offset : Offset<Vector3>
    {
    }
}