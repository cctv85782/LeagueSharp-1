﻿namespace RethoughtLib.Design.Implementations
{
    #region Using Directives

    using SharpDX;

    #endregion

    public class Vector4Offset : Offset<Vector4>
    {
    }
}