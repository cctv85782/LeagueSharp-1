﻿namespace RethoughtLib.Design.Implementations
{
    public class UIntOffset : Offset<uint>
    {
    }
}