﻿namespace RethoughtLib.Design.Implementations
{
    public class UShortOffset : Offset<ushort>
    {
    }
}