﻿namespace RethoughtLib.Design.Implementations
{
    #region Using Directives

    using SharpDX;

    #endregion

    internal class Vector2Offset : Offset<Vector2>
    {
    }
}