﻿namespace RethoughtLib.Design.Implementations
{
    public class ULongOffset : Offset<ulong>
    {
    }
}