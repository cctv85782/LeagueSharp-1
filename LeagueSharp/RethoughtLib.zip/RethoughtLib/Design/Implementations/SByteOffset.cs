﻿namespace RethoughtLib.Design.Implementations
{
    public class SByteOffset : Offset<sbyte>
    {
    }
}