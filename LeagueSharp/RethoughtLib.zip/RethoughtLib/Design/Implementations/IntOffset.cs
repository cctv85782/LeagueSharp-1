﻿namespace RethoughtLib.Design.Implementations
{
    public class IntOffset : Offset<int>
    {
    }
}