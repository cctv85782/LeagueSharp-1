﻿namespace RethoughtLib.Design.Implementations
{
    public class DoubleOffset : Offset<double>
    {
    }
}