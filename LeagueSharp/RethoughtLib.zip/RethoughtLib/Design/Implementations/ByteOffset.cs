﻿namespace RethoughtLib.Design.Implementations
{
    public class ByteOffset : Offset<byte>
    {
    }
}