﻿namespace RethoughtLib.Design.Implementations
{
    public class ShortOffset : Offset<short>
    {
    }
}