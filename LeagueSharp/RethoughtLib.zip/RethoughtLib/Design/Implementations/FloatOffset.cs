﻿namespace RethoughtLib.Design.Implementations
{
    public class FloatOffset : Offset<float>
    {
    }
}