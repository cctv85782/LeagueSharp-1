﻿namespace RethoughtLib.Design.Implementations
{
    public class DecimalOffset : Offset<decimal>
    {
    }
}