﻿namespace RethoughtLib.UI.Notifications.Designs
{
    internal class ExtendedNotificationDesign
    {
    }
}
